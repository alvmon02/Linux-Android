#/bin/bash
while true
do
	for ((i=0;$i <= 1;i++))
	do
		cat /proc/modlist
#		sleep 0.1
	done

    clear
done
