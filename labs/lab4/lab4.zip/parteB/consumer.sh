#!/bin/bash
for ((i=1;$i <= 10;i++))
do
	cat /dev/prodcons
#	sleep 0.1
done